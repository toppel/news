INSERT INTO `news` VALUES (1, 'tops');
