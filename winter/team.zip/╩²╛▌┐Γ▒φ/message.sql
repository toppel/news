INSERT INTO `message` VALUES (1, 'tops', ' i jdopag', 1, 'tops');
INSERT INTO `message` VALUES (2, 'tops', 'didididiidid', 2, 'max');
