INSERT INTO `landing` VALUES (2, 'tops', '965224');
INSERT INTO `landing` VALUES (22, 'max', '85122');
INSERT INTO `landing` VALUES (23, 'lsda', 'dkas');
INSERT INTO `landing` VALUES (24, 'TTSHHH', '954211');
INSERT INTO `landing` VALUES (25, 'jsx', '954211');
INSERT INTO `landing` VALUES (26, 'jsxs', '954211');
