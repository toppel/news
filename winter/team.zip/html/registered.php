<!DOCTYPE HTML>
<html>
<body>
<form action="../php/config.php" method="post">
用户名：<input type="text" name="usename"><br>
  密码: <input type="text" name="password"><br>
<input type="submit" value="注册">
</form>


</body>
</html>




