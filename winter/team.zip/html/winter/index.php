<?php
 $servername = "localhost";
$username = "top";
$password = "";
$dbname = "test";

// 创建连接
$conn = new mysqli($servername, $username, $password, $dbname);
// 检测连接
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

$result = mysqli_query($conn,"SELECT * FROM news WHERE id=1");
$row = mysqli_fetch_array($result);
$sql = "SELECT id,name,title,passage,time FROM user";
$results = $conn->query($sql);
?>




<!DOCTYPE html>
<html lang="en"> 
<head>
	<meta charset="UTF-8">
	<title>blog</title>
	<link rel="stylesheet" href="styles/view.css">
</head>
<body>
	<div id="bg">
		
	
	<!-- 页头开始 -->
	<div id="header" name="header">
		<ul>
			<a href="index.php"><li><div id="headerdiv">首页</div></li></a>
			<a href="##"><li><div id="headerdiv">关于我</div></li></a>
			<a href="##"><li><div id="headerdiv">
				联系我
				<div class="contact">
					<a href="##"><i class="iconfont">&#xe610;</i></a>
					<a href="##"><i class="iconfont">&#xe603;</i></a>
					<a href="##"><i class="iconfont">&#xe60c;</i></a>
				</div>
				</div></li>
			</a>
			<a href="message bored.php"><li><div id="headerdiv">留言板</div></li></a>
			<a href="##"><li class="set"><i class="iconfont">&#xe6bd;</i></li></a>
		</ul>
	</div>
	
	<!-- 正文开始 -->
	
	<div class="container">
		<div class="content1">
			<div class="content2">
				<a href="##">
					<div class="headportrait">
					
					</div>
				</a>
				<div class="hr"></div>
				<h1><div class="name"><?php echo $row['name']; ?></div></h1>
				<div class="hr"></div>
				<a href="#content3"><div class="more">MORE</div></a>
				<div class="arrow">
					<a href="#content3"><i class="iconfont" style="color:white">&#xe61e;</i></a>
				</div>
			</div>
			<div id="content3">
				<ul>
					<a href="##"><li class="guidance">PHOTO</li></a>
					<a href="##"><li class="guidance2">ARTICLE</li></a>
				</ul>
				<div class="articlecc">
					<a href="article1.html" target="_blank">
						<div class="articlec">
							<h2>我是第一篇文章</h2>
							<hr>
							<div class="article">
								<?php if ($results->num_rows > 0) {
									    $rows = $results->fetch_assoc();
                                       	for( ; $row['name'] != $rows['name'] ; ){$rows = $results->fetch_assoc();}
        								if( $row['name']==$rows['name'] ){
        									echo $rows["passage"];} else {
   																		 echo "还未发表文章";
																		 }									
																	 } else {
   																		 	echo "还未发表文章";
																		    } ?>...
							</div>
							<div class="picture">
								
							</div>
						</div>
					</a>
					<a href="article2.html" target="_blank">
						<div class="articlec">
							<h2>我是第二篇文章</h2>
							<hr>
							<div class="article">
								<?php if ($results->num_rows > 0) {
									    $rows = $results->fetch_assoc();
                                       	for( ; $row['name'] != $rows['name'] ; ){$rows = $results->fetch_assoc();}
        								if( $row['name']==$rows['name'] ){
        									echo $rows["passage"];} else {
   																		 echo "还未发表文章";
																		 }									
																	 } else {
   																		 	echo "还未发表文章";
																		    } ?>...
							</div>
							<div class="picture">
								
							</div>
						</div>
					</a>
					<a href="article3.html" target="_blank">
						<div class="articlec">
							<h2>我是第三篇文章</h2>
							<hr>
							<div class="article">
								<?php if ($results->num_rows > 0) {
									    $rows = $results->fetch_assoc();
                                       	for( ; $row['name'] != $rows['name'] ; ){$rows = $results->fetch_assoc();}
        								if( $row['name']==$rows['name'] ){
        									echo $rows["passage"];} else {
   																		 echo "还未发表文章";
																		 }									
																	 } else {
   																		 	echo "还未发表文章";
																		    } ?>...
							</div>
							<div class="picture">
								
							</div>
						</div>
					</a>
				</div>
				<div class="photocc">
					<div class="photowrap">
							<a href="##">
								<div class="photoc">
									<div class="cover1">
										
									</div>
								</div>
								<div class="photoc">
									<div class="cover">
										
									</div>
								</div>
								<div class="photoc">
									<div class="cover">
										
									</div>
								</div>
								<div class="photoc">
									<div class="cover1">
										
									</div>
								</div>
							</a>
					</div>
					<div class="bigphoto">
						
					</div>		
				</div>		
			</div>			
		</div>
	</div>
	

	<!-- 页脚开始 -->
	<div class="footer">
		<div id="copyright">
			Copyright © 2014-2016 <?php echo $row['name']; ?>博客 . By s个人博客.
		</div>
		<div id="iconc">
			<a href="##"><i class="iconfont">&#xe610;</i></a>
			<a href="##"><i class="iconfont">&#xe603;</i></a>
			<a href="##"><i class="iconfont">&#xe60c;</i></a>
			<a href="##"><i class="iconfont">&#xe61c;</i></a>
			<a href="##"><i class="iconfont">&#xe66f;</i></a>
		</div>
		<a href="#header"><div class="try"></div></a>
	</div>
	
	</div>
	<script>
	var guidance =document.querySelector('.guidance');
	var guidance2 = document.querySelector('.guidance2');
	var articlecc = document.querySelector('.articlecc');
	var photocc = document.querySelector('.photocc');
	guidance2.addEventListener("click",function(){
		articlecc.style.display = "block"
		photocc.style.display = "none"
	})
	guidance.addEventListener("click",function(){
		articlecc.style.display = "none"
		photocc.style.display = "block"
	})
	</script>
</body>
</html>